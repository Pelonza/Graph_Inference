-ReadMe-
#This randomwalk is not dumb, it restarts.
#The algorithm has an error, (hence the "not fixed"), where it restarts too often, do too an error in the order of operations in the place_next_neighbor function