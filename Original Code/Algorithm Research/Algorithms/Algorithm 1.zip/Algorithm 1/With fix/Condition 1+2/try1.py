#Erik Rye, Nick Juliano

#This will create plots for every graph you select "True" to.  You can select multiple graphs at the same time.  It will plot them on separate graphs.
#Only change the "True"'s and the "numRuns"

#You can change the name of the plots that are saved on lines 131 and 145.
#You can have the plots show as they finish by unblocking lines 132 and 146.

import matplotlib.pyplot as plt
import networkx as nx
import math
import randomwalk
import high_neighbor_degree_fixed_condition12L
import sys,time
import numpy as np
import time
graphdic={}

#This variable controls how many runs the plot is averaged over:

numRuns = 1

if False:
    ERgraph = nx.read_gexf("ER_random-1.gexf", node_type=int)
    graphdic[ERgraph] = 'Erdos-Renyi'
if False:
    BAgraph = nx.read_gexf("barabasi.gexf", node_type=int)
    graphdic[BAgraph]='Barabassi-Albert'
if True:
    FBgraph = nx.read_gexf("facebook_combined.gexf", node_type=int)
    graphdic[FBgraph]='Facebook'
if False:
    GRgraph = nx.read_gexf("General_Relativity.gexf", node_type=int)
    graphdic[GRgraph]='General Relativity'

for graph in graphdic.keys():
    print graphdic[graph] + ": start"
    stop = graph.number_of_nodes()/2 + 50
    for i in range(numRuns):


        fast_start=time.clock()        
        #Runs Algorithm
        mo, no, ed, co = [],[],[],[]
        HNDc = high_neighbor_degree_fixed_condition12L.HND(graph,i)
        tally=0
        monitor, tally = HNDc.pick_start(tally)
        l=range(50,stop,50)
        while not HNDc.stop(stop):
            HNDc.add_neighbors(monitor)
            monitor, tally = HNDc.place_next_monitor(monitor,tally)
            if len(HNDc.monitor_set) in l:    
                mo.append(len(HNDc.monitor_set))
                no.append(HNDc.result_graph.number_of_nodes())
                ed.append(HNDc.result_graph.number_of_edges())
                co.append(nx.number_connected_components(HNDc.result_graph))
                l.remove(len(HNDc.monitor_set))
            if tally>=math.log(graph.number_of_nodes()): 
                HNDc.add_neighbors(monitor)
                monitor, tally = HNDc.pick_start(tally)

            if len(HNDc.monitor_set) in l:    
                mo.append(len(HNDc.monitor_set))
                no.append(HNDc.result_graph.number_of_nodes())
                ed.append(HNDc.result_graph.number_of_edges())
                co.append(nx.number_connected_components(HNDc.result_graph))
                l.remove(len(HNDc.monitor_set))
        fast_end=time.clock()
        
        
        
        
        slow_start=time.clock()
        for num_monitors in range(50,stop,50):
            HNDc = high_neighbor_degree_fixed_condition12L.HND(graph,i)
            tally=0
            monitor, tally = HNDc.pick_start(tally)
            x=0
            while not HNDc.stop(num_monitors):
                HNDc.add_neighbors(monitor)
                monitor, tally = HNDc.place_next_monitor(monitor,tally)
                if tally>=math.log(graph.number_of_nodes()): 
                    HNDc.add_neighbors(monitor)
                    monitor, tally = HNDc.pick_start(tally)        
        slow_end=time.clock()
        
        fasttime=fast_end-fast_start
        slowtime=slow_end-slow_start
        
        print "Fast: " + str(fasttime)
        print "Slow: " + str(slowtime)
        print slowtime/fasttime
        
