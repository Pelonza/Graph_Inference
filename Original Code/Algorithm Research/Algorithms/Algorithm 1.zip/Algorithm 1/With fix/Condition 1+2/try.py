#Erik Rye, Nick Juliano

#This will create plots for every graph you select "True" to.  You can select multiple graphs at the same time.  It will plot them on separate graphs.
#Only change the "True"'s and the "numRuns"

#You can change the name of the plots that are saved on lines 131 and 145.
#You can have the plots show as they finish by unblocking lines 132 and 146.

import matplotlib.pyplot as plt
import networkx as nx
import math
import randomwalk
import high_neighbor_degree_fixed_condition12L
import sys,time
import numpy as np
import time
graphdic={}

#This variable controls how many runs the plot is averaged over:

numRuns = 5

if True:
    ERgraph = nx.read_gexf("ER_random-1.gexf", node_type=int)
    graphdic[ERgraph] = 'Erdos-Renyi'
if False:
    BAgraph = nx.read_gexf("barabasi.gexf", node_type=int)
    graphdic[BAgraph]='Barabassi-Albert'
if False:
    FBgraph = nx.read_gexf("facebook_combined.gexf", node_type=int)
    graphdic[FBgraph]='Facebook'
if False:
    GRgraph = nx.read_gexf("General_Relativity.gexf", node_type=int)
    graphdic[GRgraph]='General Relativity'

for graph in graphdic.keys():
    stop = graph.number_of_nodes()/2 + 50
    original_num_nodes = graph.number_of_nodes()
    original_num_edges = graph.number_of_edges()
    
    overall_monitors, overall_nodes, overall_edges, overall_components = [],[],[],[]
    alg1monitors, alg1nodes, alg1edges, alg1components = [],[],[],[]

    for i in range(numRuns):
        
        #Runs Algorithm
        mo, no = [],[]
        HNDc = high_neighbor_degree_fixed_condition12L.HND(graph,i)
        tally=0
        monitor, tally = HNDc.pick_start(tally)
        while not HNDc.stop(stop):
            HNDc.add_neighbors(monitor)
            print "adding neighbors"
            monitor, tally = HNDc.place_next_monitor(monitor,tally)
            if tally>=math.log(graph.number_of_nodes()): 
                print "condition jump"
                HNDc.add_neighbors(monitor)
                monitor, tally = HNDc.pick_start(tally)
            print str(len(HNDc.monitor_set))
            time.sleep(1)
            if len(HNDc.monitor_set) in range(50,stop*2,50):    
                mo.append(len(HNDc.monitor_set))
                no.append(HNDc.result_graph.number_of_nodes())
        
